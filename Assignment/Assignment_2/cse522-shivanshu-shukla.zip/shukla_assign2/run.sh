rm -f *.out
#cd ./source/
g++ -g -o Main.out ./source/Main.c -lm
cp Main.out ./bin/
#cd ..
